#ifndef __AFXWIN_H__
  #error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"
#include "memmap.h"


class CTestmemmapApp : public CWinApp
{
public:
//Constructors / Destructors
  CTestmemmapApp() noexcept;

//Methods
  BOOL InitInstance() override;

  DECLARE_MESSAGE_MAP()
};


class CDialog1 : public CDialog
{
public:
//Constructors / Destructors
  CDialog1(CWnd* pParent = nullptr);

protected:
//Member variables
  enum { IDD = IDD_DIALOG1 };
  CEdit m_ctrlEdit;
  CMemMapFile m_mmf;
  UINT_PTR m_nTimer;

//Methods
  void DoDataExchange(CDataExchange* pDX) override;
  BOOL OnInitDialog() override;

//Message Handlers
  afx_msg void OnChangeEdit1();
  afx_msg void OnDestroy();
  afx_msg void OnTimer(UINT_PTR nIDEvent);

  DECLARE_MESSAGE_MAP()
};
