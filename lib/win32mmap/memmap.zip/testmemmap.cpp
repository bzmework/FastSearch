#include "stdafx.h"
#include "testmemmap.h"


const int MAX_EDIT_TEXT = 100;
const TCHAR* g_MMFName = _T("MMFTEST");
const TCHAR* g_MMFMutexName = _T("MMFTEST_MUTEX"); 

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


#pragma warning(suppress: 26440 26433)
BEGIN_MESSAGE_MAP(CTestmemmapApp, CWinApp)
END_MESSAGE_MAP()


CTestmemmapApp::CTestmemmapApp() noexcept
{
}

#pragma warning(suppress: 26426)
CTestmemmapApp theApp;


BOOL CTestmemmapApp::InitInstance()
{
  //seed the random number generator
#pragma warning(suppress: 26472)
  srand(static_cast<unsigned int>(time(nullptr)));

  //Form a path to the test txt file we will be operating on
  TCHAR szTestFile[_MAX_PATH];
  szTestFile[0] = _T('\0');
#pragma warning(suppress: 26485)
  if (!GetModuleFileName(nullptr, szTestFile, _MAX_PATH))
  {
    CString sMsg;
    sMsg.Format(_T("Failed in call to GetModuleFileName. Error:%u"), GetLastError());
    AfxMessageBox(sMsg);
    return FALSE;
  }
  TCHAR szDrive[_MAX_DRIVE];
  szDrive[0] = _T('\0');
  TCHAR szDir[_MAX_DIR];
  szDir[0] = _T('\0');
#pragma warning(suppress: 26485)
  _tsplitpath_s(szTestFile, szDrive, sizeof(szDrive)/sizeof(TCHAR), szDir, sizeof(szDir)/sizeof(TCHAR), nullptr, 0, nullptr, 0);
#pragma warning(suppress: 26485)
  _tmakepath_s(szTestFile, sizeof(szTestFile)/sizeof(TCHAR), szDrive, szDir, _T("input"), _T("txt"));
  TCHAR szUpperCaseTestFile[_MAX_PATH];
  szUpperCaseTestFile[0] = _T('\0');
#pragma warning(suppress: 26485)
  _tmakepath_s(szUpperCaseTestFile, sizeof(szUpperCaseTestFile)/sizeof(TCHAR), szDrive, szDir, _T("outputUpperCase"), _T("txt"));
  TCHAR szLowerCaseTestFile[_MAX_PATH];
  szLowerCaseTestFile[0] = _T('\0');
#pragma warning(suppress: 26485)
  _tmakepath_s(szLowerCaseTestFile, sizeof(szLowerCaseTestFile)/sizeof(TCHAR), szDrive, szDir, _T("outputLowerCase"), _T("txt"));

  //First test out the class when we want to map a file
  //You might want to step through this code to test it out
  CMemMapFile mmf;
#pragma warning(suppress: 26485)
  BOOL bSuccess = mmf.MapFile(szTestFile, FALSE);
  VERIFY(bSuccess);
  LPVOID pData = mmf.Open();
#pragma warning(suppress: 26477)
  ATLASSUME(pData != nullptr);
  bSuccess = mmf.Flush();
  VERIFY(bSuccess);
#pragma warning(suppress: 26160)
  bSuccess = mmf.Close();
  VERIFY(bSuccess);
  mmf.UnMap();

  //Now a real demonstration of Memory mapped file usage. Make the sample input.txt file 
  //uppercase. Error checking is ignored / implemented by using VERIFY for demonstration purposes
  //The real power of memory mapped files is that this demonstration would work just as efficiently 
  //with a 100 MB file as it does with just a small text file. Note that because these samples uses 
  //CharUpperBuffA and ChatLowerBuffA, the file size must be less than 4GB since we cast to a DWORD 
  //sizes parameter 
#pragma warning(suppress: 26485)
  bSuccess = CopyFile(szTestFile, szUpperCaseTestFile, FALSE);
  VERIFY(bSuccess);
  CMemMapFile mmf3;
#pragma warning(suppress: 26485)
  bSuccess = mmf3.MapFile(szUpperCaseTestFile);
  VERIFY(bSuccess);
  pData = mmf3.Open();
#pragma warning(suppress: 26477)
  ATLASSUME(pData != nullptr);
  CFileStatus fs;
#pragma warning(suppress: 26485)
  bSuccess = CFile::GetStatus(szTestFile, fs);
  VERIFY(bSuccess);
  VERIFY(fs.m_size <= ULONG_MAX);
#pragma warning(suppress: 26472)
  CharUpperBuffA(static_cast<LPSTR>(pData), static_cast<DWORD>(fs.m_size));
#pragma warning(suppress: 26160)
  bSuccess = mmf3.Close();
  VERIFY(bSuccess);
  mmf3.UnMap();
  CString sMsg;
#pragma warning(suppress: 26485)
  sMsg.Format(_T("The file %s should be the uppercase version of %s"), szUpperCaseTestFile, szTestFile);
  AfxMessageBox(sMsg);

  //Also try lowercase version
#pragma warning(suppress: 26485)
  bSuccess = CopyFile(szTestFile, szLowerCaseTestFile, FALSE);
  VERIFY(bSuccess);
  CMemMapFile mmf4;
#pragma warning(suppress: 26485)
  bSuccess = mmf4.MapFile(szLowerCaseTestFile);
  VERIFY(bSuccess);
  pData = mmf4.Open();
#pragma warning(suppress: 26477)
  ATLASSUME(pData != nullptr);
#pragma warning(suppress: 26485)
  bSuccess = CFile::GetStatus(szTestFile, fs);
  VERIFY(bSuccess);
  VERIFY(fs.m_size <= ULONG_MAX);
#pragma warning(suppress: 26472)
  CharLowerBuffA(static_cast<LPSTR>(pData), static_cast<DWORD>(fs.m_size));
#pragma warning(suppress: 26160)
  bSuccess = mmf4.Close();
  VERIFY(bSuccess);
  mmf4.UnMap();
#pragma warning(suppress: 26485)
  sMsg.Format(_T("The file %s should be the lowercase version of %s"), szLowerCaseTestFile, szTestFile);
  AfxMessageBox(sMsg);

  //Finally a demonstration of the shared memory capabilities of 
  //memory mapped files. For this demo, we will bring up a UI which
  //will take whatever is put into its edit box and transfer it into 
  //shared memory. Then if you bring up another version of testmemmap, 
  //you will see this value being reflecting into it.
  //periodically
  CDialog1 dlg;
  dlg.DoModal();

#pragma warning(suppress: 26167)
  return FALSE;
}


#pragma warning(suppress: 26455)
CDialog1::CDialog1(CWnd* pParent) : CDialog(CDialog1::IDD, pParent),
                                    m_nTimer(0)
{
}

void CDialog1::DoDataExchange(CDataExchange* pDX)
{
  //Let the base class do its thing
  __super::DoDataExchange(pDX);

  DDX_Control(pDX, IDC_EDIT1, m_ctrlEdit);
}

#pragma warning(suppress: 26440 26433)
BEGIN_MESSAGE_MAP(CDialog1, CDialog)
  ON_EN_CHANGE(IDC_EDIT1, &CDialog1::OnChangeEdit1)
  ON_WM_DESTROY()
  ON_WM_TIMER()
END_MESSAGE_MAP()


//A sample worker thread to show how to share a memory mapped file across multiple threads
#pragma warning(suppress: 26440)
unsigned int __stdcall MoniterSM(LPVOID /*p*/)
{
  //Open up the existing MMF
  CMemMapFile mmf;
  const BOOL bSuccess = mmf.MapExistingMemory(g_MMFName, g_MMFMutexName, (MAX_EDIT_TEXT+1)*sizeof(TCHAR));
  VERIFY(bSuccess);

  while (true)
  {
    //Just modify the data with random text
    TCHAR sText[MAX_EDIT_TEXT+1];
#pragma warning(suppress: 26485)
    _stprintf_s(sText, sizeof(sText)/sizeof(TCHAR), _T("Modified from Thread %u, Random data:%d"), GetCurrentThreadId(), rand());
    LPVOID lpData = mmf.Open();
    if (lpData != nullptr)
    {
      TRACE(_T("Thread %u update\n"), GetCurrentThreadId());
#pragma warning(suppress: 26485)
      _tcscpy_s(static_cast<TCHAR*>(lpData), sizeof(sText)/sizeof(TCHAR), sText);
#pragma warning(suppress: 26110)
      mmf.Close();
    }
    else
    {
      ASSERT(FALSE);
    }
    Sleep(100);
  }
  return 0;
}

BOOL CDialog1::OnInitDialog() 
{
  //Let the base class do its thing
  __super::OnInitDialog();

  //Limit the text to the size that can be held in the MMF
  m_ctrlEdit.LimitText(MAX_EDIT_TEXT);

  //Check to see if we are the first instance
  //of this program running. In the process testing
  //the MapExistingMemory method
  if (m_mmf.MapExistingMemory(g_MMFName, g_MMFMutexName, (MAX_EDIT_TEXT+1)*sizeof(TCHAR)))
    AfxMessageBox(_T("This program is already running"));
  else
  {
    AfxMessageBox(_T("This program is the first instance"));

    //map the shared memory, 
    if (m_mmf.MapMemory(g_MMFName, g_MMFMutexName, (MAX_EDIT_TEXT+1)*sizeof(TCHAR)))
    {
      //Set the initial text which will go into the MMF
      m_ctrlEdit.SetWindowText(_T("Initial Text"));
    }
    else
    {
      AfxMessageBox(_T("Failed to map shared memory"));
      PostMessage(WM_CLOSE);
    }
  }
  
  //Create a 1 second timer to allow us to update the edit box
  m_nTimer = SetTimer(1, 1000, nullptr);
  
#ifdef _DEBUG
  //Create some test worker threads to access the MMF at the same time as the main UI thread
  UINT nThreadId = 0;
  _beginthreadex(nullptr, 0, MoniterSM, this, 0, &nThreadId);	
  _beginthreadex(nullptr, 0, MoniterSM, this, 0, &nThreadId);	
#endif

  return TRUE;
}

void CDialog1::OnChangeEdit1() 
{
  TCHAR sText[MAX_EDIT_TEXT+1];
#pragma warning(suppress: 26485)
  m_ctrlEdit.GetWindowText(sText, MAX_EDIT_TEXT);
  LPVOID lpData = m_mmf.Open();
  if (lpData)
  {
    TRACE(_T("CDialog1::OnChangeEdit1 update\n"));
#pragma warning(suppress: 26485)
    _tcscpy_s(static_cast<TCHAR*>(lpData), sizeof(sText)/sizeof(TCHAR), sText);
#pragma warning(suppress: 26110 26167)
    m_mmf.Close();
  }
}

#pragma warning(suppress: 26434)
void CDialog1::OnDestroy()
{
  KillTimer(m_nTimer);
  m_nTimer = 0;

  //Let the base class do its thing
  __super::OnDestroy();
}

#pragma warning(suppress: 26434)
void CDialog1::OnTimer(UINT_PTR /*nIDEvent*/) 
{
  //Retreive the contents of the MMF
  TCHAR sNewText[MAX_EDIT_TEXT+1];
#pragma warning(suppress: 26485)
  _tcscpy_s(sNewText, sizeof(sNewText)/sizeof(TCHAR), _T(""));
  LPVOID lpData = m_mmf.Open();
  if (lpData != nullptr)
  {
    TRACE(_T("CDialog1::OnTimer update\n"));
#pragma warning(suppress: 26485)
    _tcscpy_s(sNewText, sizeof(sNewText)/sizeof(TCHAR), static_cast<TCHAR*>(lpData));
#pragma warning(suppress: 26110)
    m_mmf.Close();
  }

  //update the edit control if the text has changed
  CString sCurrentText;
  m_ctrlEdit.GetWindowText(sCurrentText);
#pragma warning(suppress: 26167 26485)
  if (sCurrentText != sNewText)
    m_ctrlEdit.SetWindowText(sNewText);
}
